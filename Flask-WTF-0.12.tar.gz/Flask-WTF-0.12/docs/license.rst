BSD License
===========

.. include:: ../LICENSE
